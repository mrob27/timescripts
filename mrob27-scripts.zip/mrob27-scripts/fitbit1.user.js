// ==UserScript==
// @namespace http://mrob.com/time/scripts-beta
// @name Fitbit-1
// @description Look for data on a fitbit page
// @author Robert Munafo
// @version 20141113
// @downloadURL http://mrob.com/time/scripts-beta/fitbit1.user.js.txt
// @include http://*.fitbit.com/*
// @include https://*.fitbit.com/*
// @match http://*.fitbit.com/*
// @match https://*.fitbit.com/*
// ==/UserScript==

// REVISION HISTORY:
//
// 20140901 First version. It parses all the chart data and the baseline for both types of pages
// 20141113 It is fairly complete now: It constructs a URL and submits the data to my backend at mrob.com/ff.php
//   Add parsing of <tspan>s to identify vertical scale labels, and record all gleaned "steps" amounts.

// TTD:
//   Format the data as text
//   Create a text node, insert at top of page, and select the text
//   Create buttons to jump to next day / previous day

// To use this script, go to a URL like the following:
//
//    https://www.fitbit.com/2014/08/30
//    https://www.fitbit.com/activities/2014/08/29
//
// The second URL gives more detailed data. The script will wait for the
// detailed graph to be displayed, and get all the data.

console.info("Fitbit1 running");

var ttd;
var del;
var baseline = -1;
var bsls = '';
var gotdata = 0;
var scaletop = -1;

fitbit1 = {
  logit: function (dt, logdata)
  {
    var u1;
    u1 = "http://mrob.com/ff.php?date=" + dt + "&log=" + logdata;
    var req = new GM_xmlhttpRequest ({
      method: "GET",
      url:    u1,
      onload: function (resp)
      {
        console.info('sent data for ' + dt + ' to mrob.com');
      }
    });
  },

  textOf: function(obj) {
    return obj.textContent ? obj.textContent : obj.innerText;
  },

  convert: function() {
    var i, ch1, nch, ht;
    // First try to get all the data.
    var el1, dtot, agg;
    var dat = [];

    dtot = 0; agg = '';

    // Try to find the 288-element chart
    el1 = document.querySelectorAll(".highcharts-series-group");
    if (el1) {
      console.info("got data: " + (typeof el1) + ' ' + (el1.length));
      // We expect to find either 24*4 or 24*12 (96 or 288) elements
      // %%% Note that when looking at a new day with no data (as yet) we get
      // strange numbers: for example, the vertical scale might go from 0
      // to 1.5, and all the heights are 9467.
      if (el1.length > 0) {
        ch1 = el1[0].childNodes[0];
        // Get the first node, which contains the data
        if (ch1) {
          nch = ch1.childElementCount;
          for (i = 0; i < nch; i++) {
            ht = ch1.childNodes[i].height.baseVal.value;
            dat[i] = ht;
            dtot += ht;
            agg = agg + ',' + ht;
            // if (ht > 0) {
            //  console.info('at ' + i + ': '
            //                     + ch1.childNodes[i].height.baseVal.value);
            // }
          }
          console.info("all data (" + nch + " elements totalling " + dtot + "):");
          console.info(dat);
          if (nch > 0) {
            // Getting this data means we're successful.
            gotdata = nch;
            if (baseline >= 0) {
              ttd = 0;
            }
          }
        }
      }
    } else {
      console.info("Got no highcharts-series-group");
    }

    el1 = document.querySelectorAll(".highcharts-tracker");
    if (el1) {
      console.info("found a highcharts-tracker");
      // %%% Try parsing this if Fitbit removes the highcharts-series-group
    }

    // Try to get the total number of steps. Note that this usually is
    // available immediately at page load, before the data appears.
    // el1 = document.querySelectorAll(".activity-history");
    // if (el1) {
    //   // We found the "Activity History" box
    //   var ch2, ch3, ch4, ch5, ch6, ch7, ch8;
    //   console.info("got ah: " + (typeof el1) + ' ' + (el1.length));
    //   unsafeWindow.v1 = el1;
    //   if (el1.length > 0) {
    //     ch1 = el1[0];
    //     ch2 = ch1.childNodes[3];
    //     unsafeWindow.v2 = ch2;
    //     if (ch2.classList[0] === "module-content") {
    //       ch3 = ch2.childNodes[1];
    //       ch4 = ch3.childNodes[3];
    //       unsafeWindow.v4 = ch4;
    //       if (ch4.classList[0] === "totals") {
    //         ch5 = ch4.childNodes[1];
    //         ch6 = ch5.childNodes[1];
    //         unsafeWindow.v6 = ch6;
    //         if (fitbit1.textOf(ch6.childNodes[1]) === " steps") {
    //           // We found the part that says how many steps
    //           ch7 = ch6.childNodes[0];
    //           ch8 = ch7.childNodes[0];
    //           unsafeWindow.v8 = ch8;
    //           var stp = fitbit1.textOf(ch8);
    //           stp = stp.replace(/,/g, "");
    //           var sct = parseInt(stp);
    //           console.info('' + sct + ' steps');
    //           console.info("1. Baseline is " + sct);
    //         } else {
    //           console.info('Could not determine baseline');
    //         }
    //       } else {
    //         console.info("Found module-content but not totals");
    //       }
    //     } else {
    //       console.info("Found 'Activity History' but not module-content");
    //     }
    //   } else {
    //     console.info("Found no activity-history item");
    //   }
    // } else {
    //   console.info("Did not find 'Activity History' box");
    // }

    // Try to get the total number of steps. Note that this usually is
    // available immediately at page load, before the data appears.
    el1 = document.querySelectorAll(".summary");
    if (el1) {
      // We found the "summary" box
      var ch2, ch3, ch4, ch5, ch6, ch7, ch8;
      console.info("got summary: " + (typeof el1) + ' ' + (el1.length));
      unsafeWindow.v1 = el1;
      if (el1.length > 0) {
        ch1 = el1[0];
        unsafeWindow.v2 = ch1;
        if (ch1.childNodes[3]) {
          console.info('going to cN[3]');
          ch2 = ch1.childNodes[3];
        } else {
          console.info('going to cN[2]');
          ch2 = ch1.childNodes[2];
        };
        unsafeWindow.v3 = ch2;
        if (ch2.classList[0] === "totals") {
          ch3 = ch2.childNodes[1];
          ch4 = ch3.childNodes[1];
          unsafeWindow.v6 = ch4;
          if (fitbit1.textOf(ch4.childNodes[1]) === " steps") {
            // We found the part that says how many steps
            ch5 = ch4.childNodes[0];
            ch6 = ch5.childNodes[0];
            unsafeWindow.v8 = ch6;
            var stp = fitbit1.textOf(ch6);
            stp = stp.replace(/,/g, "");
            var sct = parseInt(stp);
            console.info('' + sct + ' steps');
            console.info("2. Baseline is " + sct);
            bsls = bsls + sct + ',';
            if (sct > baseline) {
              baseline = sct;
              if (gotdata > 0) {
                ttd = 0;
              }
            }
          } else {
            console.info('Could not determine baseline');
          }
        } else {
          console.info("Found summary but not totals");
        }
      } else {
        console.info("Found no summary item");
      }
    } else {
      console.info("Did not find 'Summary' box");
    }

    el1 = document.querySelectorAll(".absoluteContainer");
    if (el1) {
      var unit;
      console.info("found " + el1.length + " absoluteContainer(s)");
      // %%% We need to scan through the list and find one whose
      // units is "steps"
      console.info(el1);
      unsafeWindow.ac = el1;
      for(i=0; i<el1.length; i++) {
        // Look for the units
        ch1 = el1[i].childNodes[1];
        ch2 = ch1.childNodes[1];
        ch3 = ch2.childNodes[0];
        unit = fitbit1.textOf(ch3);
        if (typeof unit === "string") {
          // Now get the value
          ch2 = ch1.childNodes[0];
          ch3 = ch2.childNodes[0];
          stp = fitbit1.textOf(ch3);
          stp = stp.replace(/,/g, "");
          sct = Number(stp);
          console.info("" + sct + " " + unit);
          if (unit === "steps") {
            console.info("3. Baseline is " + sct);
            bsls = bsls + sct + ',';
            if (sct > baseline) {
              baseline = sct;
              if (gotdata > 0) {
                ttd = 0;
              }
            }
          }
        }
      }
    }

    var tspans = document.getElementsByTagName('tspan');
    if (tspans) {
      if (tspans.length) {
        var lc = tspans[(tspans.length - 1)];
        var lcx = lc.getAttributeNS(null,"x");
        if (parseInt(lcx) <= 54) {
          var lbl = fitbit1.textOf(lc.childNodes[0]);
          if (lbl) {
            lbl = parseInt(lbl);
            if (lbl > scaletop) {
              scaletop = lbl;
            }
          }
        }
      }
    }

    // Run myself again a couple more times, because the page doesn't have
    // the data when first loaded, it gets added by JavaScript later.
    if (ttd > 0) {
      recalc = 1;
      setTimeout(fitbit1.convert.bind(fitbit1), del);
      ttd -= 1;
      // Go to the next-higher delay interval
      if         (del <= 1011) {
        del = 2022;
      } else if  (del <= 2022) {
        del = 3111;
      } else if  (del <= 3111) {
        del = 5027;
      } else if  (del <= 5027) {
        del = 9111;
      } else if  (del <= 9111) {
        del = 100235;
      };
    } else {
      // Successful data collection, log it.
      var dt, m, dtp, pd;
      m = document.location.href.match(/\/(\d\d\d\d)\/(\d\d)\/(\d\d)/);
      if (m) {
        dt = '' + m[1] + m[2] + m[3];
        pd = parseInt(m[3]) - 1;
        if (pd < 10) {
          pd = '0' + pd;
        }
        dtp = 'https://fitbit.com/activities/' + m[1] + '/' + m[2] + '/' + pd;
        console.info(dt);
        console.info('' + bsls + '+' + scaletop + '+' + agg);
        fitbit1.logit(dt, '' + bsls + '+' + scaletop + '+' + agg);
        // console.info('previous day: ' + dtp);
      }
    };
  }
};

// Make it run itself a few more times, because I suspect that other
// fb JavaScript might run even after the 'load', 'onload', and
// 'DOMContentLoaded' events have all fired.
ttd = 3; del = 1011;

// 3 cases for cross-platform, cross-browser: not necessary for this
// application but I want this code to be useful elsewhere too!
if (window.addEventListener) {
  window.addEventListener('DOMContentLoaded', // was 'load',
    fitbit1.convert.bind(fitbit1), false);
} else if (window.attachEvent) {
  window.attachEvent('onload',
    fitbit1.convert.bind(fitbit1));
} else {
  fitbit1.convert(fitbit1);
};
